package com.training;

import org.springframework.stereotype.Component;

@Component
public class Car {
	
	public void applyAccelerator(){
		
		System.out.println("Accelerator is applied ");
	}
	public void applyBrake(){
		
		System.out.println("Brake is applied ");
	}
}
