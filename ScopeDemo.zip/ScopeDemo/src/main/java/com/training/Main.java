package com.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String arg[]) {
		
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		//Driver d =  context.getBean("driver",Driver.class);
		
		//d.drive();
		
		Car c1=context.getBean("maruti",Car.class);
		
		Car c2 =context.getBean("maruti",Car.class);
		
		boolean isSame = c1==c2;
		
		System.out.println("Both are same instances:"+isSame);
		
		
		
	}

}
