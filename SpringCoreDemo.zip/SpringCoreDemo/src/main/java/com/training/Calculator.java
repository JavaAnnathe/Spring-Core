package com.training;

public class Calculator {
	
	public Calculator(){}
	
	public int add(int i,int k){
		
		return i+k;
	}

}
