package com.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String arg[]) {
		
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		Greeting greet =  context.getBean("greet",Greeting.class);
		
		greet.sayHello();
		
		Calculator c = context.getBean("calculate", Calculator.class);
		
		System.out.println("Value of 3+5:"+c.add(3, 5));
		
		
	}

}
