package com.training;

public class Greeting {
	
	public Greeting(){}
	
	public void sayHello(){
		
		System.out.println("Hello");
	}

}
