package com.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.PermanentEmployee;

public class PermanentEmployeeRetrieveByIDDemo {
	
	public static void main(String arg[]) {
	
	// loading the definitions from the given XML file
			ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
					 
			PermenantEmpDAO dao =  context.getBean("permenantEmpDAO",PermenantEmpDAO.class);
			
			
			
			System.out.println("----------------------------------");
			
			
			PermanentEmployee pe =dao.getPermanentEmployeeByEmployeeId(1000);
			System.out.println("Employee Id "+pe.getEmployeeId());
			System.out.println("Employee name "+pe.getName());
			System.out.println("Employee designation "+pe.getDesignation());
			System.out.println("Employee basic salary "+pe.getBasicSalary());
	}
}
