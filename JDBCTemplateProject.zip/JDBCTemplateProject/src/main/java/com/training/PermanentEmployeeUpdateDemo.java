package com.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.PermanentEmployee;

public class PermanentEmployeeUpdateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
								 
		PermenantEmpDAO dao =  context.getBean("permenantEmpDAO",PermenantEmpDAO.class);
		
		dao.updatePermanentEmployee(new PermanentEmployee(1000,"Ramasubramanian", "Developer",50000));
		
		System.out.println("Records updated");
				
	}

}
