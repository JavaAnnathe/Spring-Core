package com.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.PermanentEmployee;

public class PermanentEmployeeAddDemo {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
						 
		PermenantEmpDAO dao =  context.getBean("permenantEmpDAO",PermenantEmpDAO.class);
		
		
		dao.addPermanentEmployee(new PermanentEmployee(1000,"Ram", "Developer",50000));
		
		dao.addPermanentEmployee(new PermanentEmployee(1001,"Vivek", "Tech Lead",70000));
		
		
		System.out.println("Records added");
		
	}

}
