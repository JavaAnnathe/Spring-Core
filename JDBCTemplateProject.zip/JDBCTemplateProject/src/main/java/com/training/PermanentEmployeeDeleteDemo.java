package com.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PermanentEmployeeDeleteDemo {

	public static void main(String[] args) {
		
		//PermanentEmployeeService service =  new PermanentEmployeeService();
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
								 
		PermenantEmpDAO dao =  context.getBean("permenantEmpDAO",PermenantEmpDAO.class);
		
		System.out.println("Records deleted");
		
		
				
		dao.deletePermanentEmployee(1000);
		dao.deletePermanentEmployee(1001);
		
		
		

	}

}
