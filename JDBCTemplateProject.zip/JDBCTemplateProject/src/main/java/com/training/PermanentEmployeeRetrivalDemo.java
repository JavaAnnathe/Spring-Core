package com.training;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.PermanentEmployee;



public class PermanentEmployeeRetrivalDemo {
	
	
	public static void main(String arg[]){
		
		
		//PermanentEmployeeService service =  new PermanentEmployeeService();
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
				 
		PermenantEmpDAO dao =  context.getBean("permenantEmpDAO",PermenantEmpDAO.class);
		
		
		//retrieving all employees
		
		List permanentEmployeeList =dao.getAllPermanentEmployees(); 
		
		System.out.println("----------------------------------");
		Iterator<PermanentEmployee> iterator = permanentEmployeeList.iterator();
		  
		  while(iterator.hasNext()){
		  
		  PermanentEmployee pe = iterator.next();
		  
		  System.out.println("Employee Id "+pe.getEmployeeId());
		  System.out.println("Employee name "+pe.getName());
		  System.out.println("Employee designation "+pe.getDesignation());
		  System.out.println("Employee basic salary "+pe.getBasicSalary());
		  
		  }
		
		
		
		
		
		
		
	}

}
