package com.training;

import java.io.FileNotFoundException;



public class PermanentEmployee extends Employee  {
	
	private int rating;
	
	public int getRating() {
		return rating;
	}

	private String designation;
	
	private float basicSalary;
	
	public PermanentEmployee(){
		
		System.out.println("Inside PermanentEmployee no org constructor");
	}
	
	public PermanentEmployee(int id,String name, String desgn,float basic){
		super(id,name);
		//System.out.println("Inside PermanentEmployee parameterized constructor");
		
		this.designation=desgn;
		this.basicSalary=basic;
	}
	
	public float getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}

	
	
	
	
	public String getDesignation() {
		return designation;
	}



	public void setDesignation(String designation) {
		this.designation = designation;
	}


}
