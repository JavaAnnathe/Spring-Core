package com.training;

public class Car {
	
	public void applyAccelerator(){
		
		System.out.println("Accelerator is applied ");
	}
	public void applyBrake(){
		
		System.out.println("Brake is applied ");
	}
}
