package com.training;

public class Driver {
	
	private Car maruti;
	
	public Driver(){
		
		
	}

	
	public Driver(Car maruti) {
		
		this.maruti = maruti;
	}


	public Car getMaruti() {
		return maruti;
	}

	public void setMaruti(Car maruti) {
		this.maruti = maruti;
	}
	
	public void drive(){
		
		maruti.applyAccelerator();
		maruti.applyBrake();
	}

}
